package abstraction;

abstract class Car
{
	abstract void run();
}
class Hyundai extends Car{
	public void run()
	{
		System.out.println("hyundai car is running ");
	}
}

public class AbstractDemo {

	public static void main(String[] args) {
		
		Hyundai h=new Hyundai();
		h.run();
		

	}

}
