package inheritance;

public class Main {
	public static void main(String args[])
	{
		Dog labrador =new Dog();
		
		labrador.name ="Scooby";
		labrador.display();
		labrador.eat();
	}

}
