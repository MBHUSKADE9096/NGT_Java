package java_assignment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConvertHashmapToList {
	public static void main(String args[])
	{
		Map<Integer,String> map = new HashMap<>();
		map.put(1,"a");
		map.put(2,"b");
		map.put(3,"c");
		map.put(4,"d");
		map.put(5,"e");
		List<Integer> keylist=new ArrayList(map.keySet());
		List<String> valuelist=new ArrayList(map.values());
		
		System.out.println("Key List:" + keylist);
		System.out.println("Value List:" + valuelist);
		
	}

}
