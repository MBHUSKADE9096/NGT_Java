package java_assignment;

public class ConvertCharacterToString {
	public static void main(String args[])
	{
		char ch='c';
		String st=Character.toString(ch);
		//Alternatively
		//st=String.valueOf(ch);
		
		System.out.println("The string is:" +st);
	}

}
