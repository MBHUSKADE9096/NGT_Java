package java_assignment;

import java.util.Scanner;

public class Palindrome {
	public static void main(String args[])
	{
		String str ="abcd" ,reverseStr =  "";
		int strLenght= str.length();
		for(int i=(strLenght-1);i>=0;--i)
		{
			reverseStr =reverseStr +str.charAt(i);
			
		}
		if (str.toLowerCase().equals(reverseStr.toLowerCase()))
		{
			System.out.println(str + "is a Palindrome String.");
		}
		else
		{
			System.out.println(str + "is not a Palindrome String.");
		}
		

}
}
