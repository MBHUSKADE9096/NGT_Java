package java_assignment;

public class ReverseSentenceUsingRecursion {
	public static void main(String[] args)
	{
		String sentence ="Don't Be Lazy";
		String reversed =reverse(sentence);
		System.out.println("The reversedsentence is:" +reversed);
		
	}
	public static String reverse(String sentence)
	{
		if(sentence.isEmpty())
		{
			return sentence;
		}
		return reverse(sentence.substring(1)) + sentence.charAt(0);
		
	}

}
