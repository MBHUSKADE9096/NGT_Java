package java_assignment;

public class ProgramsOnPyramid {
public static void main(String[] args) {
		
		//Half Pyramid
		
		for(int i=1; i<5; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("* ");
			}
			System.out.println("");
		}
		System.out.println("");
		
		
		
		// Triangular pyramid
		
		System.out.println("...............Another Pattern.............");
		System.out.println("");
		
		int r=5, a = 0;

	    for (int i=1; i<=r; ++i, a=0)
	    { 
	    	
	      for (int j=1; j<=r-i; ++j)
	      {
	        System.out.print("  ");
	      }

	      while (a!=2*i - 1) 
	      {
	        System.out.print("* ");
	        ++a;
	      }

	      System.out.println();
	    }
	    // Inverted Full Pyramid

		System.out.println("...............Another Pattern.............");
		System.out.println("");
		int rows = 5;

	    for(int i = rows; i >= 1; --i) {
	      for(int space = 1; space <= rows - i; ++space) {
	        System.out.print("  ");
	      }

	      for(int j=i; j <= 2 * i - 1; ++j) {
	        System.out.print("* ");
	      }

	      for(int j = 0; j < i - 1; ++j) {
	        System.out.print("* ");
	      }

	      System.out.println();
	    }
	  }
	

	    
	  }
	
		
	




