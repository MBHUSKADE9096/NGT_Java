package java_assignment;

public class MoveAllZeroes {
	
	public static void main(String[] args) {
	
	int a[]= {1,0,7,8,6,4,0,0};
	int count=0;
	for(int i=0;i<a.length;i++) {
	if(a[i]!= 0) {
	a[count++]=a[i];
	}
	}
	while(count<a.length) {
	a[count++]=0;
	}
	for(int j=0;j<a.length;j++) {
	System.out.print(a[j]+" ");
	}
	}
	}

	


