package java_assignment;

public class LargestElementArray {
	public static void main(String args[])
	{
		int[] arr=new int [] {24,67,99,34,98};
		int max=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
				max=arr[i];
		}
		System.out.println("Largest element present in given array:"+max);
	}

}
