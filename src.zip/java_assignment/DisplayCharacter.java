package java_assignment;

public class DisplayCharacter {
	public static void main(String[] args) 
	{
		char c;
		for(c= 'A'; c <= 'Z'; ++c)
		{
			System.out.print(c + "");
		
	    }

    }
}
