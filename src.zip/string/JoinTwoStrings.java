package string;

public class JoinTwoStrings {
	public static void main(String args[])
	{
		//create first string
		String first="Hello";
	    System.out.println("First String:" +first);
	    
	    //create second string
	    String second="World";
	    System.out.println("Second String:" +second);
	    
	    //join two string
	    String joinedString=first.concat(second);
	    System.out.println("Joined String:" +joinedString);
	}

}
