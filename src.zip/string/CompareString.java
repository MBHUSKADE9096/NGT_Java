package string;

public class CompareString {
	public static void main(String args[])
	{
		//create a string
		String first="GoodAfternoon";
		String second="GoodAfternoon";
		String third="Welcome";
		
		//compare first and second string
		boolean result1=first.equals(second);
		System.out.println("Strings first ans second are equal:" + result1);
		
		//compare first and third string
		boolean result2=first.equals(third);
		System.out.println("Strings first ans third are equal:" + result2);
		
	}
	

}
