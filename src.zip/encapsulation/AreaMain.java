package encapsulation;

public class AreaMain {
	public static void main(String args[])
	{
		Area rectangle =new Area (9,10);
		rectangle.getArea();
	}
	

}
