package encapsulation;

public class CarMain {
	public static void main(String args[])
	{
		Car c= new Car();
		System.out.println(c.getcarName());
		System.out.println(c.getcarColour());
		
	}

}
