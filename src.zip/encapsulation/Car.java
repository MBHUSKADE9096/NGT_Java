package encapsulation;

public class Car {
	private String  carName;
	private String  carColour;
	
	public void setcarName(String carName)
	{
		this.carName=carName;
	}
	public String getcarName()
	{
		return carName;
	}
	public void setcarColour(String carColour)
	{
		this.carColour=carColour;
	}
	public String getcarColour()
	{
		return carColour;
	}
	

}
