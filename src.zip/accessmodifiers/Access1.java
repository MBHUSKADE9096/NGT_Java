package accessmodifiers;

public class Access1 {
	//default , public ,private and protected
	
	public int hours=3;
	public int minutes =47;
	
	//private int hours=3;
	//private int minutes =47;
	
	//protected int hours=3;
	//protected int minutes =47;

}
