package control_flow_statements;

public class DoWhileLoop {
	public static void main (String args[])
	{
		int i=0;
		System.out.println("Printing the list of first 10 even numbers \n");
		do
		{
			System.out.println(i);
			i=i+2;
		}
		while(i<=10);
	}

}
