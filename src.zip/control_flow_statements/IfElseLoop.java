package control_flow_statements;

public class IfElseLoop {
	public static void main (String args[])
	{
		int x=12;
		int y=9;
		
		if(x+y<12)
		{
			System.out.println("x+y is less than 12");
		}
		else
		{
			System.out.println("x+y is greater than 20");
		}
	}

}
