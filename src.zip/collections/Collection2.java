package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Collection2 {
	public static void main(String args[])
	{
		LinkedList<String> names =new LinkedList<>();
		//add elements
		names.add("Sam");
		names.add("Sayna");
		names.add("Shruti");
		names.add("Priyanka");
		Iterator<String>itr=names.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
	}

}


