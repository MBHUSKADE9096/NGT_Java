package collections;

import java.util.ArrayList;

public class Collection1 {
	public static void main(String args[])
	{
		ArrayList<String> animals=new ArrayList<>();
		//add elements
		animals.add("Dog");
		animals.add("Cat");
		animals.add("Tiger");
		System.out.println("ArrayList:" +animals);
		
	}

}
