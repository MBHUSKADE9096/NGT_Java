package type_conversion;

public class Types {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int n=(int) 2.5;
          
         System.out.println(n);
          
          byte a=4;
          short b;
          char c;
          int d;
          long e;
          float f;
          double g;
          
          
          double ex=a;
          
          //int ex=a;
          //short ex=a;
          //byte ex=a;
          //char ex=a;
          //long ex=a;
          //float ex=a;
          //double ex=a;
          
          
          
	}

}
