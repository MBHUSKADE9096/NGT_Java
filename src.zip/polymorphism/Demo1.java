package polymorphism;

class Bird
{
	public void sing()
	{
		System.out.println("tweet tweet tweet");
	}
}
class Robin extends Bird
{
	public void sing()
	{
		System.out.println("tweet tweet ");
	}
}


public class Demo1 {
	public static void main(String args[])
	{
		Bird b=new Bird();
		b.sing();
		
		//Robin b=new Robin();
		//b.sing();
	}

}
