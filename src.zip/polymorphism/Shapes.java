package polymorphism;

public class Shapes {
	
	public void render()
	{
		System.out.println("Rendering Polygon...");
	}
}
	
	class Square extends Shapes
	{
		//renders Square
		public void render()
		{
			System.out.println("Rendering Square");
		}
	}
	class Circle extends Shapes
	{
		//renders circle
		public void render()
		{
			System.out.println("Rendering Circle");
		}
	}


