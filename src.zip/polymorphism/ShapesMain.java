package polymorphism;


public class ShapesMain {
	public static void main(String[] args)
	{
		Square s1=new Square();
		s1.render();
		
		Circle c1=new Circle();
		s1.render();
		
	}

}
