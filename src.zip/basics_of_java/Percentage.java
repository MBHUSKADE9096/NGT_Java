package basics_of_java;

import java.util.Scanner;

public class Percentage {
	public static void main (String args[])
	{
		float percentage;
		float totalmarks;
		float scored;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter your marks::");
		scored=sc.nextFloat();
		
		System.out.println("Enter totak marks ::");
		totalmarks=sc.nextFloat();
		
		percentage=(float)((scored/totalmarks)*100);
		System.out.println("Percentage ::" + percentage);
		
	}
	

}
