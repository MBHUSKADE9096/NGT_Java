package basics_of_java;

public class Operators {
	public static void main (String args[])
	{
		//declare variables
		int a=60, b=5;
		
		//addition operators
		System.out.println(" a + b = " + (a + b));
		
		//subtraction operator
		System.out.println(" a - b = " + (a - b));
		
		//multiplication operator
		System.out.println(" a * b = " + (a * b));
		
		//division operator
		System.out.println(" a / b = " + (a / b));
		
		//modulo operator
		System.out.println(" a % b = " + (a % b));
		
		
	}

}
