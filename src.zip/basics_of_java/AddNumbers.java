package basics_of_java;

public class AddNumbers {
	public static void main(String args[])
	{
		System.out.println("Enter two numbers");
		int first=70;
		int second=10;
		
		System.out.println(first + " " + second);
		
		
		//add two numbers
		int sum =first+second;
		System.out.println("The sum is:" +sum);
	}

}
